package aishwarya.flutter_basic_news;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
